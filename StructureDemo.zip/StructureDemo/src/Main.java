public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        SequenceStorageList sequenceStorageList = new SequenceStorageList(100);
        try {
            sequenceStorageList.insert(1,100);
            sequenceStorageList.insert(1,200);
            sequenceStorageList.insert(1,300);
            sequenceStorageList.insert(1,400);
            sequenceStorageList.insert(1,500);
            sequenceStorageList.insert(1,600);
            sequenceStorageList.insert(1,700);
            sequenceStorageList.insert(1,800);
            sequenceStorageList.insert(1,900);
            sequenceStorageList.insert(1,1000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        sequenceStorageList.print();
        System.out.println("Find 500: "+sequenceStorageList.find(500));
        try {
            sequenceStorageList.delete(6);
            sequenceStorageList.print();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}