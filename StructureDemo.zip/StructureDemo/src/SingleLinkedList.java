

public class SingleLinkedList {
    class Node{
        int data;
        Node next=null;
        public Node(int d){
            data=d;
        }
    }

    private Node head=null;
    private int length=0;

    /**
     * 头插法
     * @param d
     */
    public void insertNodeTail(int d){
        length++;
        if(head==null){
            head=new Node(d);
            return;
        }
        Node newNode = new Node(d);
        Node tmp=head;
        while (tmp.next!=null){
            tmp=tmp.next;
        }
        tmp.next=newNode;
    }

    /**
     * 尾插法
     * @param d
     */
    public void insertNodeHeader(int d){
        length++;
        if(head==null){
            head=new Node(d);
            return;
        }
        Node newNode = new Node(d);
        Node temp = head;
        head=newNode;
        newNode.next=temp;
    }

    public int find(int position) throws Exception {
        if(position>length||position<1){
            throw new Exception("position 不合法");
        }
        int index=0;
        Node temp=head;
        while(index<position-1){
            index++;
            temp=temp.next;
        }
        return temp.data;
    }

    public void delete(int position) throws Exception {
        if(position>length||position<1){
            throw new Exception("position 不合法");
        }
        if(length==1){
            head=null;
            length--;
        }else if(length==2){
            if(position==1){
                head=head.next;
                head.next=null;
            }
            else{
                head.next=null;
            }
            length--;
        }
        else{
            if(position==1){
                head=head.next;
                length--;
            }
            else{
                int index=0;
                Node temp=head;
                while(index<position-2){
                    index++;
                    temp=temp.next;
                }
                if(temp.next.next==null){
                    temp.next=null;
                }else{
                    Node q = temp.next;
                    temp.next=q.next;
                }
                length--;
            }
        }

    }
}
