/**
 * 数据结构:
 * 顺序存储结构
 * 增删查操作操作
 */
public class SequenceStorageList {
    private int last;
    private int[] storage;
    private int MAXSIZE;
    public SequenceStorageList(int max){
        this.MAXSIZE=max;
        this.last=-1;
        storage=new int[MAXSIZE];
    }
    public void insert(int i,int newValue) throws Exception {
        if(i<1||i>last+2){
            throw new Exception("Position i is error");
        }
        if(last>=MAXSIZE-1){
            throw new Exception("SequenceStorageList is full");
        }
        for (int j=last;j>=i-1;j--){
            storage[j+1]=storage[j];
        }
        storage[i-1]=newValue;
        last++;
    }

    public void delete(int i) throws Exception {
        if (last == -1) {
            throw new Exception("表为空，不能删除！");
        }
        if(i<1||i>last+1){
            throw new Exception("Position i is error");
        }
        for (int j=i-1;j<=last;j++){
            storage[j]=storage[j+1];
        }
        last--;
    }

    public int find(int value){
        int position = -1;
        for (int j=0;j<=last;j++){
            if(storage[j]==value){
                position=j;
                break;
            }
        }
        return position==-1?position:position+1;
    }

    public void print(){
        for (int i=0;i<=last;i++){
            System.out.print(storage[i] + "\t");
        }
        System.out.println();
    }
}
